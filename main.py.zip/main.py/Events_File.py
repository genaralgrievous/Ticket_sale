class Event:
    """Base class for all events."""
    pass

# Event classes
class TicketPurchaseRequestEvent(Event):
    name = 'ticket_purchase_request'

    def __init__(self, user_id, concert_id, num_tickets):
        self.user_id = user_id
        self.concert_id = concert_id
        self.num_tickets = num_tickets

class TicketPurchaseConfirmationEvent(Event):
    name = 'ticket_purchase_confirmation'

    def __init__(self, request_id, is_confirmed):
        self.request_id = request_id
        self.is_confirmed = is_confirmed

class TicketCancellationEvent(Event):
    name = 'ticket_cancellation'

    def __init__(self, user_id, concert_id):
        self.user_id = user_id
        self.concert_id = concert_id

class CancellationConfirmationEvent(Event):
    name = 'cancellation_confirmation'

    def __init__(self, request_id, is_confirmed):
        self.request_id = request_id
        self.is_confirmed = is_confirmed

# Shared communication queue
communication_queue = []