from Agents_File import TicketPlatform
from Agents_File import User
from Agents_File import Concert



# Simple user interface
def main():
    platform = TicketPlatform()

    # Register users
    platform.register_user(1, "Alice", "alice@example.com")
    platform.register_user(2, "Bob", "bob@example.com")

    # Add concerts
    platform.add_concert(101, "Rock Fest", "2025-05-10", 100)
    platform.add_concert(102, "Jazz Night", "2025-06-15", 50)

    while True:
        print("\n--- Ticket Sales System ---")
        print("1. Buy Tickets")
        print("2. Cancel Tickets")
        print("3. Process Events")
        print("4. Exit")

        choice = input("Choose an option: ")

        if choice == '1':
            user_id = int(input("Enter User ID: "))
            concert_id = int(input("Enter Concert ID: "))
            num_tickets = int(input("Enter number of tickets: "))
            if user_id in platform.users:
                platform.users[user_id].request_ticket_purchase(concert_id, num_tickets)
            else:
                print("User not found!")

        elif choice == '2':
            user_id = int(input("Enter User ID: "))
            concert_id = int(input("Enter Concert ID: "))
            if user_id in platform.users:
                platform.users[user_id].request_ticket_cancellation(concert_id)
            else:
                print("User not found!")

        elif choice == '3':
            platform.process_events()

        elif choice == '4':
            print("Exiting...")
            break

        else:
            print("Invalid choice! Try again.")

if __name__ == "__main__":
    main()

print("can")
