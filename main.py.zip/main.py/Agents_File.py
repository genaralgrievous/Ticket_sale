# Core classes
from Events_File import Event
from Events_File import TicketPurchaseRequestEvent
from Events_File import TicketPurchaseConfirmationEvent
from Events_File import TicketCancellationEvent
from Events_File import CancellationConfirmationEvent

communication_queue = []

class User:
    def __init__(self, user_id, name, email):
        self.user_id = user_id
        self.name = name
        self.email = email

    def request_ticket_purchase(self, concert_id, num_tickets):
        event = TicketPurchaseRequestEvent(user_id=self.user_id, concert_id=concert_id, num_tickets=num_tickets)
        communication_queue.append(event)
        print(f'Event {event.name} emitted by {self.name}!')

    def request_ticket_cancellation(self, concert_id):
        event = TicketCancellationEvent(user_id=self.user_id, concert_id=concert_id)
        communication_queue.append(event)
        print(f'Event {event.name} emitted by {self.name}!')


class Concert:
    def __init__(self, concert_id, name, date, total_tickets):
        self.concert_id = concert_id
        self.name = name
        self.date = date
        self.total_tickets = total_tickets
        self.available_tickets = total_tickets

    def handle_ticket_request(self):
        if communication_queue:
            event = communication_queue.pop(0)
            if isinstance(event, TicketPurchaseRequestEvent):
                print(f"Processing ticket purchase request for {event.num_tickets} tickets by User {event.user_id}.")
                if self.available_tickets >= event.num_tickets:
                    self.available_tickets -= event.num_tickets
                    confirmation = TicketPurchaseConfirmationEvent(request_id=event.user_id, is_confirmed=True)
                    communication_queue.append(confirmation)
                    print(f"{event.num_tickets} tickets confirmed for User {event.user_id}.")
                else:
                    confirmation = TicketPurchaseConfirmationEvent(request_id=event.user_id, is_confirmed=False)
                    communication_queue.append(confirmation)
                    print("Not enough tickets available.")

            elif isinstance(event, TicketCancellationEvent):
                print(f"Processing cancellation request from User {event.user_id}.")
                self.available_tickets += 1
                confirmation = CancellationConfirmationEvent(request_id=event.user_id, is_confirmed=True)
                communication_queue.append(confirmation)
                print(f"Cancellation confirmed for User {event.user_id}.")


class TicketPlatform:
    def __init__(self):
        self.users = {}
        self.concerts = {}

    def register_user(self, user_id, name, email):
        self.users[user_id] = User(user_id, name, email)
        print(f"User {name} registered successfully!")

    def add_concert(self, concert_id, name, date, total_tickets):
        self.concerts[concert_id] = Concert(concert_id, name, date, total_tickets)
        print(f"Concert '{name}' added with {total_tickets} tickets.")

    def process_events(self):
        for concert in self.concerts.values():
            concert.handle_ticket_request()
